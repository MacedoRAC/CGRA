#ifndef MYUNITCUBE_H
#define MYUNITCUBE_H

#include "CGFobject.h"

class myUnitCube: public CGFobject {
	public:
		void draw();
};

#endif