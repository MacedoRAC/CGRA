#include"MyRobot.h"
#include "CGFapplication.h"

MyRobot:: MyRobot(){

}

void MyRobot:: draw(){

	glTranslatef(8, 0, 8.5);
	glRotatef(-150,0,1,0);

	glBegin(GL_TRIANGLES);
		glVertex3f(0.5, 0.3, 0);
		glVertex3f(-0.5, 0.3, 0);
		glVertex3f(0, 0.3, 2);
	glEnd();
}