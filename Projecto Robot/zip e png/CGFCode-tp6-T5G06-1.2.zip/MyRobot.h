#ifndef MyRobot_H
#define MyRobot_H

class MyRobot{
public:
	MyRobot();
	void draw();
};

#endif