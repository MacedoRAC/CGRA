#ifndef MY_CYLINDER
#define MY_CYLINDER

#include "CGF/CGFobject.h"

class myCylinder : public CGFobject {

	public:
		myCylinder(int slices, int stacks/*, bool smooth*/);

};



#endif
